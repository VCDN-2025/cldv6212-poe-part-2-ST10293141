using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Azure.Storage;
using Azure.Storage.Sas;
using Azure.Storage.Files.Shares;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;

public class FileShareFunction
{
    private readonly string? _connection;
    private readonly string? _accountName;
    private readonly string? _accountKey;

    public FileShareFunction()
    {
        _connection = Environment.GetEnvironmentVariable("AzureStorageConnectionString")!;
        var parts = _connection.Split(';', StringSplitOptions.RemoveEmptyEntries);
        foreach (var p in parts)
        {
            if (p.StartsWith("AccountName")) _accountName = p.Split('=')[1].Trim();
            if (p.StartsWith("AccountKey")) _accountKey = p.Split('=')[1].Trim();
        }

        if (string.IsNullOrEmpty(_accountName) || string.IsNullOrEmpty(_accountKey))
        {
            throw new InvalidOperationException("AccountName or AccountKey could not be retrieved from connection string.");
        }
    }

    [Function("GetFiles")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "files")] HttpRequestData req)
    {
        string shareName = "contracts";
        var shareClient = new ShareClient(_connection, shareName);
        var credential = new StorageSharedKeyCredential(_accountName, _accountKey);

        var results = new List<object>();
        var root = shareClient.GetRootDirectoryClient();
        await foreach (var item in root.GetFilesAndDirectoriesAsync())
        {
            if (!item.IsDirectory)
            {
                var fileClient = root.GetFileClient(item.Name);
                var sasBuilder = new ShareSasBuilder
                {
                    ShareName = shareName,
                    FilePath = item.Name,
                    ExpiresOn = DateTimeOffset.UtcNow.AddHours(4)
                };
                sasBuilder.SetPermissions(ShareFileSasPermissions.Read);
                var sas = sasBuilder.ToSasQueryParameters(credential).ToString();
                results.Add(new
                {
                    item.Name,
                    Url = $"{fileClient.Uri}?{sas}"
                });
            }
        }

        var res = req.CreateResponse(HttpStatusCode.OK);
        await res.WriteAsJsonAsync(results);
        return res;
    }
}


//Microsoft. 2025. Azure Functions developer guide. [online] Available at: //https://learn.microsoft.com/en-us/azure/azure-functions/functions-overview
//[Accessed 6 October 2025].

//Microsoft. 2025a. Azure Storage File Shares and SAS tokens. [online] //Available at: https://learn.microsoft.com/en-us/azure/storage/files/storage-dotnet-how-to-use-files
//[Accessed 6 October 2025].