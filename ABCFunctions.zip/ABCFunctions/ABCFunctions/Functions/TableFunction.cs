using System.Collections.Generic;
using System.Threading.Tasks;
using Azure.Data.Tables;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;

public class TableFunction
{
    private readonly string _connection;

    public TableFunction()
    {
        _connection = Environment.GetEnvironmentVariable("AzureStorageConnectionString")!;
    }

    [Function("GetTables")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "tables")] HttpRequestData req)
    {
        var tables = new[] { "Customers", "Products" };
        var output = new Dictionary<string, List<IDictionary<string, object>>>();

        foreach (var t in tables)
        {
            var client = new TableClient(_connection, t);
            var results = new List<IDictionary<string, object>>();

            await foreach (var entity in client.QueryAsync<TableEntity>())
            {
                results.Add(entity);
            }

            output[t] = results;
        }

        var res = req.CreateResponse(HttpStatusCode.OK);
        await res.WriteAsJsonAsync(output);
        return res;
    }
}


//Microsoft. 2025. Azure Functions developer guide. [online] Available at: //https://learn.microsoft.com/en-us/azure/azure-functions/functions-overview
//[Accessed 6 October 2025].

//Microsoft. 2025a. Azure Storage File Shares and SAS tokens. [online] //Available at: https://learn.microsoft.com/en-us/azure/storage/files/storage-dotnet-how-to-use-files
//[Accessed 6 October 2025].