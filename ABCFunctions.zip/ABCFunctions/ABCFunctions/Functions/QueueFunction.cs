using System.Collections.Generic;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;

public class QueueFunction
{
    private readonly string _connection;

    public QueueFunction()
    {
        _connection = Environment.GetEnvironmentVariable("AzureStorageConnectionString")!;
    }

    [Function("GetQueues")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "queues")] HttpRequestData req)
    {
        var queues = new[] { "op-logs", "ops-logs" };
        var output = new List<object>();

        foreach (var name in queues)
        {
            var client = new QueueClient(_connection, name);
            if (await client.ExistsAsync())
            {
                var msgs = await client.PeekMessagesAsync(maxMessages: 5);
                var texts = new List<string>();
                foreach (var msg in msgs.Value)
                    texts.Add(msg.MessageText);

                output.Add(new { Queue = name, Messages = texts });
            }
            else
            {
                output.Add(new { Queue = name, Error = "Queue not found" });
            }
        }

        var res = req.CreateResponse(HttpStatusCode.OK);
        await res.WriteAsJsonAsync(output);
        return res;
    }
}


//Microsoft. 2025. Azure Functions developer guide. [online] Available at: //https://learn.microsoft.com/en-us/azure/azure-functions/functions-overview
//[Accessed 6 October 2025].

//Microsoft. 2025a. Azure Storage File Shares and SAS tokens. [online] //Available at: https://learn.microsoft.com/en-us/azure/storage/files/storage-dotnet-how-to-use-files
//[Accessed 6 October 2025].