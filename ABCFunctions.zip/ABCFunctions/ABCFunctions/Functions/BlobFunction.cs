using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using Azure.Storage;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;

public class BlobFunction
{
    private readonly string _connection;
    private readonly string _accountName;
    private readonly string _accountKey;

    public BlobFunction()
    {
        
        _connection = Environment.GetEnvironmentVariable("AzureStorageConnectionString")!;

        if (string.IsNullOrWhiteSpace(_connection))
            throw new InvalidOperationException("AzureStorageConnectionString is missing or not set.");

        
        var parts = _connection.Split(';', StringSplitOptions.RemoveEmptyEntries);
        foreach (var p in parts)
        {
            if (p.StartsWith("AccountName=", StringComparison.OrdinalIgnoreCase))
                _accountName = p.Split('=')[1];
            else if (p.StartsWith("AccountKey=", StringComparison.OrdinalIgnoreCase))
                _accountKey = p.Split('=')[1];
        }

        if (string.IsNullOrWhiteSpace(_accountName) || string.IsNullOrWhiteSpace(_accountKey))
            throw new InvalidOperationException("Invalid connection string � missing AccountName or AccountKey.");
    }

    [Function("GetBlobs")]
    public async Task<HttpResponseData> GetBlobs(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "blobs")] HttpRequestData req)
    {
        var containerName = "media";

        try
        {
            var containerClient = new BlobContainerClient(_connection, containerName);
            var credential = new StorageSharedKeyCredential(_accountName, _accountKey);

            var blobList = new List<object>();

            await foreach (var blob in containerClient.GetBlobsAsync())
            {
                var blobClient = containerClient.GetBlobClient(blob.Name);

                // Build SAS token for each blob (4-hour expiry)
                var sasBuilder = new BlobSasBuilder
                {
                    BlobContainerName = containerName,
                    BlobName = blob.Name,
                    ExpiresOn = DateTimeOffset.UtcNow.AddHours(4)
                };
                sasBuilder.SetPermissions(BlobSasPermissions.Read);

                string sasToken = sasBuilder.ToSasQueryParameters(credential).ToString();
                string blobUrl = $"{blobClient.Uri}?{sasToken}";

                blobList.Add(new { blob.Name, Url = blobUrl });
            }

            var response = req.CreateResponse(HttpStatusCode.OK);
            await response.WriteAsJsonAsync(blobList);
            return response;
        }
        catch (Exception ex)
        {
            var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
            await errorResponse.WriteStringAsync($"Error: {ex.Message}");
            return errorResponse;
        }
    }
}


//Microsoft. 2025. Azure Functions developer guide. [online] Available at: //https://learn.microsoft.com/en-us/azure/azure-functions/functions-overview
//[Accessed 6 October 2025].

//Microsoft. 2025a. Azure Storage File Shares and SAS tokens. [online] //Available at: https://learn.microsoft.com/en-us/azure/storage/files/storage-dotnet-how-to-use-files
//[Accessed 6 October 2025].